# memmap
Trim and save the Linux runtime snapshot image

## How to build
```
make
```

## How to use
### Generate the example json file
```
./memmap -e
{
        "ddr-base":     0,
        "sector-size":  0,
        "zero-page":    false,
        "auto-mode":    false,
        "secure":       false,
        "mem-map":      {
                "canary":       0,
                "resume":       0,
                "mem-map":      0,
                "max-mapnr":    0,
                "struct-size":  0,
                "page-size":    0,
                "page-type":    0,
                "page-off":     0,
                "order-off":    0,
                "linux-ver":    0
        }
}
```
Save the json file:
```
./memmap -e > snapshot.json
```
### Update the parameters in the json file
This is an example:
```
cat snapshot.json 
{
        "ddr-base":     0x60000000,
        "sector-size":  0x200,
        "zero-page":    true,
        "auto-mode":    false,
        "secure":       false,
        "mem-map":      {
                "canary":       0x60e08550,
                "resume":       0x6010ab98,
                "mem-map":      0x63f7a000,
                "max-mapnr":    0x4000,
                "struct-size":  0x20,
                "page-size":    0x1000,
                "page-type":    0xf0,
                "page-off":     0x18,
                "order-off":    0x14,
                "linux-ver":    0
        }
}
```
### Trim and save the Linux runtime snapshot image
```
./memmap -i 6_12_48.bin -o out.bin
Save 6_12_48.bin to out.bin
Page usage: 53% (8844/16384)
Zero usage: 8% (1321/16384)
```
Use "-V" for more information:
```
./memmap -i 6_12_48.bin -o out.bin -V
Save 6_12_48.bin to out.bin
Page usage: 53% (8844/16384)
Zero usage: 8% (1321/16384)
snapshot:
        ddr-base:    0x60000000
        sector-size: 0x200
        zero-page:   true
        auto-mode:   false
        secure:      false
mem-map:
        canary:      0x60e08550
        resume:      0x6010ab98
        mem-map:     0x63f7a000
        max-mapnr:   0x4000
        struct-size: 0x20
        page-size:   0x1000
        page-type:   0xf0
        page-off:    0x18
        order-off:   0x14
        linux-ver:   0
header:
        magic:       0xa5a5a5a5
        canary:      0x60e08550
        resume:      0x6010ab98
        mem_map:     0x63f7a000
        max_mapnr:   0x4000
        linux_ver:   0
        data_offset: 0x1200
        flags:       0x00000001
        c_bitmap[0]: 0x000000c7
        c_bitmap[1]: 0x00000000
        c_bitmap[2]: 0x00000000
        c_bitmap[3]: 0x00000000
```
