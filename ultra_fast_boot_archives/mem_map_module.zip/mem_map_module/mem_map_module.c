#include <linux/module.h>
#include <linux/init.h>
#include <linux/mm.h>
#include <linux/highmem.h>
#include <linux/suspend.h>
#include <asm/suspend.h>

static int __init mem_map_init(void)
{
	pr_info("AT91: PM: mem_map     = 0x%x\n\r", __pa_symbol(mem_map));
	pr_info("AT91: PM: page_size   = 0x%lx\n\r", PAGE_SIZE);
	pr_info("The maximum Number of Mapped Pages: 0x%lx\n", max_mapnr);
	pr_info("The sizeof 'Page' Structure: 0x%x\n", sizeof(struct page)); 
	pr_info("The offset of 'page_type' in 'page' structure: 0x%x\n", offsetof(struct page, page_type));
	pr_info("The offset of 'private' in 'Page' structure: 0x%x\n", offsetof(struct page, private));	return 0;
}

static void __exit mem_map_exit(void)
{
	pr_info("Exiting mem_map module.\n");
}

module_init(mem_map_init);
module_exit(mem_map_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Print mem_map Address");
MODULE_AUTHOR("Your Name");
